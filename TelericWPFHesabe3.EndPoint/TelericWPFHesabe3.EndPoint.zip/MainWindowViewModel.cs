﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

using TelericWPFHesabe3.EndPoint.Settings.InformationSetting;

using Telerik.Windows.Controls;

namespace TelericWPFHesabe3.EndPoint
{
    public class MainWindowViewModel : ViewModelBase
    {
        public ICommand ShowInformationSettingCommand { get; set; }
        public override ICommand ClosingWindowCommand { get; set; }
        public override ICommand CloseWindowCommand { get ; set; }

        private void showInformationSetting(object obj)
        {
            var informationView = App.GetWindow<InformationSettingView, InformationSettingViewModel,MainWindow>();
            informationView.ShowDialog();
        }

        public override void ClosingWindow(object obj)
        {
            
        }

        public override void CloseWindow(object obj)
        {
            
        }

        public MainWindowViewModel()
        {
            ShowInformationSettingCommand = new DelegateCommand(showInformationSetting);
        }
    }
}
